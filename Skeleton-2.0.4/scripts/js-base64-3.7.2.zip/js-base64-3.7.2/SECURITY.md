# Security Policy

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| 3.x.x   | :white_check_mark: |
| < 2.x   | :white_check_mark:  security fixes only |

## Reporting a Vulnerability

Please mail it to the author, dankogai+github@gmail.com .
